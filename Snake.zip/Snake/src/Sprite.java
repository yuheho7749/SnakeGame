/**
 * Defines the basic structure of a sprite.
 * @author Joseph Ng
 * @version 1.0
 */


import javafx.scene.layout.*;

abstract public class Sprite {
	protected double moveSpd;
	protected double velocityX;
	protected double velocityY;
	protected Pane model;

	public Sprite() {
		this.moveSpd = 0;
		this.velocityX = 0;
		this.velocityY = 0;
		this.model = new Pane();
	}

	abstract public void update();

	public Pane getModel() {return this.model;}
	public double getMoveSpd() {return this.moveSpd;}
	public double getVelocityX() {return this.velocityX;}
	public double getVelocityY() {return this.velocityY;}

	public void setModel(Pane m) {this.model = m;}
	public void setMoveSpd(double mS) {this.moveSpd = mS;}
	public void setVelocityX(double vX) {this.velocityX = vX;}
	public void setVelocityY(double vY) {this.velocityY = vY;}

}