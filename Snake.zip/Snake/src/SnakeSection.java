/**
 * Defines a section of the snake body.
 * @author Joseph Ng
 * @version 1.0
 */

import javafx.scene.shape.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;

public class SnakeSection extends Sprite {
	private StackPane design;
	private Rectangle body;

	public SnakeSection(double s) {
		super();
		this.createDesign();
		this.setBodySize(s);
		this.model.getChildren().add(this.design);
	}

	private void createDesign() {
		this.design = new StackPane();
		this.body = new Rectangle();
		this.body.setFill(Color.rgb(50, 50, 50));
		this.body.setStroke(Color.rgb(200, 200, 200));
		this.design.getChildren().addAll(this.body);
	}

	public void setBodySize(double s) {
		this.body.setWidth(s * .8);
		this.body.setHeight(s * .8);
		this.body.setStrokeWidth(s * .1);
	}

	@Override
	public void update() {
		
	}
}