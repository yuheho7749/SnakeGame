/**
 * Controls the logic of the snake game.
 * @author Joseph Ng
 * @version 1.0
 */


import java.util.ArrayList;

import javafx.scene.layout.*;
import javafx.scene.input.*;
import javafx.event.*;
import javafx.animation.*;
import javafx.application.*;
import javafx.event.*;
import javafx.scene.paint.*;
import javafx.scene.control.*;

import javafx.util.*;
import javafx.geometry.*;

public class Game {
	private String name = "Snake";
	private double width, height;
	private double gridSizeX = 50;
	private double gridSizeY = 30;
	private double scaleFactor = 20; // 25 recommended (Require at least 10)
	private double fps = 15; // best at 10-20 fps
	private Pane world;
	private SnakeBody snake;
	private Label scoreLabel;
	private Timeline timeline;
	private boolean running;
	private Label youLoseLabel;
	private boolean pause;
	private Label pauseLabel;
	private int snakeStartSize = 4;
	private ArrayList<Food> foods = new ArrayList<Food>();

	public Game() {
		this.world = new Pane();
		this.world.setStyle("-fx-background-color: Ivory; -fx-border-width: 1px; -fx-border-color: Black;");
		this.width = this.gridSizeX * this.scaleFactor;
		this.height = this.gridSizeY * this.scaleFactor;
		this.world.setPrefSize(this.width, this.height);

		this.snake = new SnakeBody(this, this.scaleFactor);
		for (int i = 0; i < 1; i ++) {
			this.foods.add(new Food(this.scaleFactor));
		}

		this.scoreLabel = new Label();
		this.scoreLabel.setStyle("-fx-font-size: " + Integer.toString((int)(this.gridSizeY)));

		this.youLoseLabel = new Label("You Lose!");
		this.youLoseLabel.setTextFill(Color.RED);
		this.youLoseLabel.setStyle("-fx-font-weight: Bold; -fx-font-size: " + Integer.toString((int)(2 * this.gridSizeX)));
		this.youLoseLabel.setLayoutX(this.width * .27);
		this.youLoseLabel.setLayoutY(this.height * .33);

		this.pauseLabel = new Label("Paused");
		this.pauseLabel.setTextFill(Color.GRAY);
		this.pauseLabel.setStyle("-fx-font-weight: Bold; -fx-font-size: " + Integer.toString((int)(2 * this.gridSizeX)));
		this.pauseLabel.setLayoutX(this.width * .33);
		this.pauseLabel.setLayoutY(this.height * .33);

		this.initTimeline();
	}

	public String getName() {return this.name;}
	public double getWidth() {return this.width;}
	public double getHeight() {return this.height;}
	public Pane getWorld() {return this.world;}
	public Timeline getTimeline() {return this.timeline;}
	public boolean getRunning() {return this.running;}

	public void setName(String n) {this.name = n;}
	public void setWidth(double w) {this.width = w;}
	public void setHeight(double h) {this.height = h;}
	public void setWorld(Pane w) {this.world = w;}

	public void reset() {
		this.pause = false;
		this.running = true;
		this.timeline.play();

		this.world.getChildren().removeAll(this.world.getChildren());

		this.snake.resetScore();
		this.scoreLabel.setText(Integer.toString(this.snake.getScore()));
		this.world.getChildren().add(scoreLabel);

		while (this.snake.getSnakeBody().size() > 0) {
			this.snake.getSnakeBody().remove(0);
		}

		for (Food food : this.foods) {
			this.setNewFoodLocation(food);
			this.world.getChildren().add(food.getModel());
		}

		// init snake and set it to go right always
		for (int i = 0; i < this.snakeStartSize; i ++) {
			this.world.getChildren().add(this.snake.addSnakeSection(((int)this.gridSizeX/2 - this.snakeStartSize) + i, ((int)this.gridSizeY/2 - 1)).getModel());
		}
		this.snake.setIsMoveRight(true);
		
	}

	public void endGame() {
		this.running = false;
		this.timeline.pause();

		// show you lose
		this.world.getChildren().add(this.youLoseLabel);
		System.out.println("Score: " + this.snake.getScore());
	}

	private void togglePause() {
		this.snake.setIsThisFrameUpdated(!this.snake.getIsThisFrameUpdated());
		this.pause = !this.pause;
		if (this.pause) {
			this.timeline.pause();
			this.world.getChildren().add(this.pauseLabel);
		} else {
			this.timeline.play();
			this.world.getChildren().remove(this.pauseLabel);
		}
	}

	private void setNewFoodLocation(Food food) {
		food.getModel().setLayoutX((int)(Math.random() * this.gridSizeX) * this.scaleFactor);
		food.getModel().setLayoutY((int)(Math.random() * this.gridSizeY) * this.scaleFactor);
	}

	public void handleMovement(KeyEvent event) {
		if (!this.running) {this.reset();}
		switch (event.getCode()) {
			case P:
				this.togglePause();
				break;
			case W: case UP:
				if (!this.snake.getIsMoveDown()) {
					this.snake.setIsMoveUp(true);
				}
				break;
			case S: case DOWN:
				if (!this.snake.getIsMoveUp()) {
					this.snake.setIsMoveDown(true);
				}
				break;
			case A: case LEFT:
				if (!this.snake.getIsMoveRight()) {
					this.snake.setIsMoveLeft(true);
				}
				break;
			case D: case RIGHT:
				if (!this.snake.getIsMoveLeft()) {
					this.snake.setIsMoveRight(true);
				}
				break;
		}
	}

	public void initTimeline() {
		this.timeline = new Timeline(new KeyFrame(Duration.millis(1000 / this.fps), ae -> update()));
		this.timeline.setCycleCount(Animation.INDEFINITE);
	}

	public void update() {
		// update snake
		this.snake.update();

		SnakeSection head = this.snake.getSnakeSection(this.snake.getSnakeBody().size() - 1);

		// test for eating food
		for (Food food : this.foods) {
			if (head.getModel().getBoundsInParent().intersects(food.getModel().getBoundsInParent())) {
				this.snake.eat();
				this.scoreLabel.setText(Integer.toString(this.snake.getScore()));
				this.setNewFoodLocation(food);
			}
		}

		// test for collide with self
		for (SnakeSection other : this.snake.getSnakeBody()) {
			if (head != other && head.getModel().getBoundsInParent().intersects(other.getModel().getBoundsInParent())) {
				System.out.println("What does your own body taste like?");
				this.endGame();
			}
		}

		// test for collide with wall
		if (head.getModel().getLayoutX() < 0 || head.getModel().getLayoutX() + head.getModel().getWidth() > this.world.getWidth() ||
			head.getModel().getLayoutY() < 0 || head.getModel().getLayoutY() + head.getModel().getHeight() > this.world.getHeight()) {
			System.out.println("I hope your face doesn't need plastic surgery after hitting that wall...");
			this.endGame();
		}

		

		
	}



}