/**
 * Controls the main application.
 * @author Joseph Ng
 * @version 1.0
 */

import java.util.ArrayList;

import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.input.*;
import javafx.scene.control.*;
import javafx.animation.*;
import javafx.application.*;
import javafx.event.*;

import javafx.util.*;
import javafx.geometry.*;

public class Snake extends Application {
	private Game game;

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) {
		this.game = new Game();
		this.game.initTimeline();

		BorderPane root = new BorderPane();

		HBox title = new HBox();
		title.setAlignment(Pos.CENTER);
		title.setPadding(new Insets(5, 5, 5, 5));
		title.setStyle("-fx-background-color: Brown;");
		Label titleName = new Label(this.game.getName());
		titleName.setTextFill(Color.rgb(50, 255, 50));
		titleName.setStyle("-fx-font-size: 30; -fx-font-weight: Bold;");
		title.getChildren().add(titleName);
		
		root.setCenter(this.game.getWorld());
		root.setTop(title);

		Scene scene = new Scene(root);
		scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				if (event.getCode().equals(KeyCode.ESCAPE)) {Platform.exit();}
				game.handleMovement(event);
			}
		});

		primaryStage.setTitle(this.game.getName());
		primaryStage.setScene(scene);
		// primaryStage.setResizable(false);
		primaryStage.show();
	}

	

}