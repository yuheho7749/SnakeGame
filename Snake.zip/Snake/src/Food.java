/**
 * Defines a food for the snake.
 * @author Joseph Ng
 * @version 1.0
 */

import javafx.scene.shape.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;

public class Food extends Sprite {
	private StackPane design;
	private Rectangle body;

	public Food(double s) {
		super();
		this.createDesign();
		this.setBodySize(s);
		this.model.getChildren().add(this.design);
	}

	private void createDesign() {
		this.design = new StackPane();
		this.body = new Rectangle();
		this.body.setFill(Color.RED);
		this.body.setStroke(Color.rgb(200, 50, 50));
		this.design.getChildren().addAll(this.body);
	}

	public void setBodySize(double s) {
		this.body.setWidth(s * .7);
		this.body.setHeight(s * .7);
		this.body.setStrokeWidth(s * .15);
	}

	@Override
	public void update() {
		
	}
}