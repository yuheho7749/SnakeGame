/**
 * Stores the body of the snake.
 * @author Joseph Ng
 * @version 1.0
 */

import java.util.*;

public class SnakeBody {
	private Game game;
	private ArrayList<SnakeSection> snakeBody = new ArrayList<SnakeSection>();
	private final double sectionSize;
	private boolean isMoveRight;
	private boolean isMoveLeft;
	private boolean isMoveUp;
	private boolean isMoveDown;
	private boolean isThisFrameUpdated;
	private int score;
	private boolean grow;

	public SnakeBody(Game game, double s) {
		this.game = game;
		this.sectionSize = s;
		this.isMoveRight = false;
		this.isMoveLeft = false;
		this.isMoveUp = false;
		this.isMoveDown = false;
		this.isThisFrameUpdated = false;
		this.grow = false;
	}
	

	public ArrayList<SnakeSection> getSnakeBody() {return this.snakeBody;}
	public SnakeSection getSnakeSection(int i) {return this.snakeBody.get(i);}
	public int getScore() {return this.score;}
	public boolean getGrow() {return this.grow;}
	public boolean getIsThisFrameUpdated() {return this.isThisFrameUpdated;}

	public boolean getIsMoveUp() {return this.isMoveUp;}
	public boolean getIsMoveDown() {return this.isMoveDown;}
	public boolean getIsMoveLeft() {return this.isMoveLeft;}
	public boolean getIsMoveRight() {return this.isMoveRight;}

	public void setIsThisFrameUpdated(boolean b) {this.isThisFrameUpdated = b;}
	public void eat() {this.score ++; this.grow = true;}
	public void resetScore() {this.score = 0; this.grow = false;}

	public void setIsMoveUp(boolean u) {
		if (!this.isThisFrameUpdated) {
			this.isMoveUp = u;
			this.isMoveDown = !u;
			this.isMoveLeft = !u;
			this.isMoveRight = !u;
			this.isThisFrameUpdated = true;
		}
		
	}
	public void setIsMoveDown(boolean d) {
		if (!this.isThisFrameUpdated) {
			this.isMoveUp = !d;
			this.isMoveDown = d;
			this.isMoveLeft = !d;
			this.isMoveRight = !d;
			this.isThisFrameUpdated = true;
		}
		
	}
	public void setIsMoveLeft(boolean l) {
		if (!this.isThisFrameUpdated) {
			this.isMoveUp = !l;
			this.isMoveDown = !l;
			this.isMoveLeft = l;
			this.isMoveRight = !l;
			this.isThisFrameUpdated = true;
		}
		
	}
	public void setIsMoveRight(boolean r) {
		if (!this.isThisFrameUpdated) {
			this.isMoveUp = !r;
			this.isMoveDown = !r;
			this.isMoveLeft = !r;
			this.isMoveRight = r;
			this.isThisFrameUpdated = true;
		}
		
	}

	public void moveRight() {
		SnakeSection oldHead = this.snakeBody.get(this.snakeBody.size() - 1);
		SnakeSection newHead;
		if (this.grow) {
			newHead = new SnakeSection(this.sectionSize);
			this.game.getWorld().getChildren().add(newHead.getModel());
		} else {
			newHead = this.snakeBody.remove(0);
		}
		newHead.getModel().setLayoutX(oldHead.getModel().getLayoutX() + this.sectionSize);
		newHead.getModel().setLayoutY(oldHead.getModel().getLayoutY());
		this.snakeBody.add(newHead);
	}
	public void moveLeft() {
		SnakeSection oldHead = this.snakeBody.get(this.snakeBody.size() - 1);
		SnakeSection newHead;
		if (this.grow) {
			newHead = new SnakeSection(this.sectionSize);
			this.game.getWorld().getChildren().add(newHead.getModel());
		} else {
			newHead = this.snakeBody.remove(0);
		}
		newHead.getModel().setLayoutX(oldHead.getModel().getLayoutX() - this.sectionSize);
		newHead.getModel().setLayoutY(oldHead.getModel().getLayoutY());
		this.snakeBody.add(newHead);
	}
	public void moveDown() {
		SnakeSection oldHead = this.snakeBody.get(this.snakeBody.size() - 1);
		SnakeSection newHead;
		if (this.grow) {
			newHead = new SnakeSection(this.sectionSize);
			this.game.getWorld().getChildren().add(newHead.getModel());
		} else {
			newHead = this.snakeBody.remove(0);
		}
		newHead.getModel().setLayoutX(oldHead.getModel().getLayoutX());
		newHead.getModel().setLayoutY(oldHead.getModel().getLayoutY() + this.sectionSize);
		this.snakeBody.add(newHead);
	}
	public void moveUp() {
		SnakeSection oldHead = this.snakeBody.get(this.snakeBody.size() - 1);
		SnakeSection newHead;
		if (this.grow) {
			newHead = new SnakeSection(this.sectionSize);
			this.game.getWorld().getChildren().add(newHead.getModel());
		} else {
			newHead = this.snakeBody.remove(0);
		}
		newHead.getModel().setLayoutX(oldHead.getModel().getLayoutX());
		newHead.getModel().setLayoutY(oldHead.getModel().getLayoutY() - this.sectionSize);
		this.snakeBody.add(newHead);
	}

	public SnakeSection addSnakeSection(double x, double y) {
		SnakeSection sS = new SnakeSection(this.sectionSize);
		sS.getModel().setLayoutX(x * this.sectionSize);
		sS.getModel().setLayoutY(y * this.sectionSize);
		this.snakeBody.add(sS);
		return sS;
	}

	public void update() {
		if (this.isMoveRight) {
			this.moveRight();
		} else if (this.isMoveLeft) {
			this.moveLeft();
		} else if (this.isMoveUp) {
			this.moveUp();
		} else if (this.isMoveDown) {
			this.moveDown();
		}
		this.isThisFrameUpdated = false;
		this.grow = false;
	}
}